﻿namespace WindowsFormsApp3.Properties
{


    partial class DataSet4
    {
    }
}


