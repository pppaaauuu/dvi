﻿namespace WindowsFormsApp3.Properties
{


    partial class DataSet2
    {
        partial class DataTableDataTable
        {
        }
    }
}

namespace WindowsFormsApp3.Properties.DataSet2TableAdapters {
    
    
    public partial class DataTableTableAdapter {
    }
}
